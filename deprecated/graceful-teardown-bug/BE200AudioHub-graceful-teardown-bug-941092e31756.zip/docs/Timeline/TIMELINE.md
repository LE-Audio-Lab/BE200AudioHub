# BE200AudioHub — 跨 Round 工程时间线 / Timeline

> **活动时间线**：Round1–4 历史 Experiment 归档 + Round5–9 Review / product-path continuation · Windows 用户态 Intel BE200 + Galaxy Buds3 Pro。
>
> 本文件是导航和对照索引，**不替代各 Round 原始纪要**。历史文档中“当前 / 下一步 / 未完成”的字样只对该 Round 当时成立。尤其 §1–§6 保留早期 Experiment/Round4 截点视角，其中的“下一步 R5.3”等不是当前 roadmap。Experiment historical baseline 与 Review current baseline 必须分开理解；Round6 在 Review-2D real HIL 后封板，Round7 完成 product semantic/data path，Round8 完成 V2 structural + live-relay baseline，Round9 当前处理 long-session teardown / crash recovery / ACL boundary。

## 阅读入口

| 文档 | 内容 | 读法 |
|---|---|---|
| [README.md](./README.md) | 归档导览 / 文档规范 | **首先阅读** |
| [AllRounds.md](./AllRounds.md) | 四轮原文完整汇编（依序） | 要看连续原始过程 |
| [Round1.md](./Round1.md) | Rust/WinUSB、Intel firmware、HCI、BLE 广播 | R1.1–R1.6 |
| [Round2.md](./Round2.md) | Bumble-RS Host 引入、无 Reset attach、扫描、首条 ACL；后续 Pairing 的**设计** | R2.1–R2.3 |
| [Round3.md](./Round3.md) | R2.4 两成员 SMP/Bond/CSIS 落地、Stored Verify、R3 双 ACL + Audio Service discovery | R2.4、R3 |
| [Round4.md](./Round4.md) | Codec/QoS/CIG/CIS 全控制面；三次 R5.2-B HIL | R4.1–R5.2-B |
| [Round5.md](./Round5.md) | R5.3 First Sound、Experiment sealed、Review-1 Runtime/Async Transport | R5.3 / Review-1 |
| [Round6.md](./Round6.md) | Review-2A/2B/2C/2D software + real HIL、ToolHub locked workflow、Apache-2.0 governance；内部 chat migration 后继续完成 2D | Review-2A / 2B / 2C / 2D closure |
| [Round7.md](./Round7.md) | Control semantic path、valid LC3 Media/Clock/Bridge、logical HCI ISO、First Sound | Round7 closure |
| [Round8.md](./Round8.md) | V2 Structural / Ownership Refactor + Windows live relay + first longevity baseline | Round8 closure |
| [Round9.md](./Round9.md) | Long-session teardown、crash recovery、ASCS/ACL lower-boundary diagnosis | **current handoff** |
| [BUG_FIX_REGISTER.md](./BUG_FIX_REGISTER.md) | **跨 Round Bug、Quirk、失败假设、修复和验证总账** | 排障与回归时阅读 |

## 1. 全程里程碑（实际实施顺序）

| Round / 时间 | 技术门槛 | 最后可证明的状态 | 代表性事实 / 记录 |
|---|---|---|---|
| Round 1 · 2026-10-11 | R1.3a/b 设备绑定 | **HIL PASS** | 仅对 BE200 `8087:0036` 手动绑 WinUSB，普通权限 Rust 可 Claim/Release Interface 0 |
| Round 1 | R1.4 Intel Vendor HCI | **HIL PASS** | 独立 `0xFC05` 读到 Operational image 0x03 |
| Round 1 | R1.5a / R1.5b 固件解析与独立冷启 | **HIL PASS** | 原厂 003 / Rust 004：3,960 条 Secure Send 逐包匹配，Bootstrap 到 Operational |
| Round 1 | R1.6a / R1.6b | **HIL PASS** | CIS Central=true；ISO buffer **248 B × 8**；LE Extended Passive Scan 看到 B3P |
| Round 2 · 2026-10-11 至 10-12 | R2.1 Bumble-RS no-reset attach | **HIL PASS** | 固定 Bumble-RS `bbac2a6`、不用 `Device::power_on`/HCI Reset |
| Round 2 | R2.2 实时 BLE scan | **HIL PASS** | Bumble `take_advertisements` 接收真实 Buds3 Pro 广播 |
| Round 2 | R2.3 首条物理 LE ACL | **HIL PASS** | 同进程 scan→connect→保持 2 s→HCI Disconnect；命令 Reason 0x13，事件 Reason 0x16 |
| Round 2 截止点 | R2.4 SMP/双耳配对 | **当时仅规划** | 不能引用 Round2 为“Bond 已完成”的证据；由 Round3 后续完成 |
| Round 3 · 2026-10-13 至 10-14 | R2.4 Primary Swift Pair + 次成员 pairing | **HIL PASS** | 两成员独立 IRK/LTK；ProvisionalBond→encrypted CSIS→原子 Commit；每耳只配一次 |
| Round 3 | Stored Bond Verify | **HIL PASS** | IRK 解析当前 RPA→FAL→stored LTK 加密→CSIS SIRK/Rank；**零 SMP** |
| Round 3 | R3 双加密 ACL / PACS / ASCS / CAS | **HIL PASS** | Resolver List + identity FAL；右 rank1/Location=2，左 rank2/Location=1；同一时间两 ACL |
| Round 4 · 2026-10-13 至 10-14 | R4.1 Codec Plan | **HIL PASS** | 每耳 ASE1；LC3 48 kHz/10 ms/100 octets/Mono，Media Context |
| Round 4 | R4.2 Config Codec + Release | **HIL PASS** | CP Success + ASE Notification + GATT Readback；两耳 Release Idle；解决 Idle 多余 3 byte |
| Round 4 | R5.1 QoS Plan | **HIL PASS（Dry Run）** | 读取真机偏好 RTN=13、Max Transport Latency=95 ms、固定 Presentation Delay=40 ms |
| Round 4 | R5.2-A HCI Set CIG + ASCS Config QoS | **HIL PASS** | CIG1 分配 CIS1/2，双耳 QoS Configured、Release、Remove CIG；**还未建立 CIS** |
| Round 4 | R5.2-B ASCS Enable + Create Dual CIS | **HIL PASS（第 3 次）** | 两条 LE CIS Established、两耳 Streaming、显式断开两 CIS、Release 两耳、Remove CIG、Bond fingerprint unchanged |
| **下一步** | **R5.3 ISO Data Path + LC3 First Sound** | **未 HIL / 未产生声学证据** | Setup/Remove ISO Path，HCI ISO transport，编码和音频时序仍要实施 |
| 未来 | R6 Lifecycle / Stability / Daily | 未开始产品验收 | 异常恢复、重复运行、声像/时延/稳定性等 |

### 状态不能越级

```text
WinUSB Open → Intel Operational → BLE Advertisement → LE ACL
           → SMP/CSIS Bond → dual encrypted ACL + PACS/ASCS
           → Codec Configured → QoS Configured
           → CIG allocated → 2 × CIS Established → CIS teardown verified
           --------------------------------------- Round4 LAST HIL GATE
           → ISO Data Path setup → LC3 SDU TX → First Sound → R6
           --------------------------------------- NOT YET DONE
```

尤其：`ISO Buffer` 只说明控制器有能力；`Set CIG` 只分配 Handle；`LE CIS Established` 也**不等于**已经有音频。R5.2-B 在没有 ISO Data Path/LC3 数据的情况下能使两耳 ASE 自行达到 `Streaming (0x04)`。

## 2. 四轮技术选型和决策演化

| 问题 | 最初思路 | 后续实证修正 / 当前决定 | 原文 |
|---|---|---|---|
| Windows LE Audio 控制权 | 在系统 Host 上 Keepalive Relay 回避随机声像问题 | 独立 BE200 Rust/WinUSB Host，Relay 继续独立项目 | [R1 §1](./Round1.md) |
| Intel 固件 | 外部 Linux SFI 先实验 | 从 `ibtusb.sys` 复原与 003 完全匹配的 Windows OEM Build 176 SFI；只在 Bootloader 守卫加载一次 | [R1 §3](./Round1.md) |
| Bluetooth Host | 审 BTstack Lite，一度倾向自写 BAP Client | 优先复用现成标准实现；最后固定 Bumble-RS `bbac2a6`，对照 AOSP/Zephyr/Linux | [R1 §5](./Round1.md)、[R2 §2](./Round2.md)、[R3 §10](./Round3.md) |
| Controller Attach | 常规 Host power_on / HCI Reset | BE200 已 Operational 时采用 no-reset `initialize_existing_operational` | [R2 §4](./Round2.md) |
| 第一次 Pairing | 直接连同名公有 LE Audio 广播 | Primary 使用 Microsoft Swift Pair pairing-only transport；次成员 RSI 候选 + generic bond/CSIS | [R3 §4–§8](./Round3.md) |
| Initiating | Explicit Peer `LE Extended Create Connection` | 成熟 generic **Filter Accept List** Connection Manager | [R3 §11](./Round3.md) |
| BLE Privacy | Scan 到 RPA 后留着稍后连接 | IRK 解析可见性；Controller Resolving List + FAL **固定 identity** 实时匹配 RPA | [R3 §21–§22](./Round3.md) |
| Bond 持久化 | Pairing 成功即保存 | ProvisionalBond 先经加密 CSIS SIRK/Size/Rank gate，再唯一 `commit.rs` 原子提交；以后只用存储 LTK | [R3 §12](./Round3.md) |
| 物理左/右 | CSIS Rank 直觉代表左右 | PACS Sink Audio Location 是唯一真相源；**rank1=Right, rank2=Left**（实测仅此型号） | [R3 §24](./Round3.md) |
| ASCS Idle 解析 | Bumble-RS 全值严格解析 | **只有 Idle** 解析 ASE ID/State，记录并忽略剩余字节；其它状态仍严格 | [R4 §4](./Round4.md) |
| 写命令成功判据 | ATT Write 返回 | CP Response + ASE Notification + 独立 Readback，缺一不可 | [R4 §4](./Round4.md) |
| QoS 策略 | 以默认值硬编码 | 耳机真实返回偏好与约束，BE200 能力 gate 和双 CIS 可调度性由控制器 HIL 最终判断 | [R4 §5](./Round4.md) |
| CIS 建立 | 同时验证所有阶段 | R5.2-A 先证明 CIG+QoS，R5.2-B 再 Enable+Create CIS+Cleanup | [R4 §6–§7](./Round4.md) |
| CIS Host 前置条件 | 只检查 CIS Central bit28 | **LE CIS Host Support bit32** 先于任何 ACL 设置并读回 | [R4 §7.2](./Round4.md) |
| Teardown | 直接 HCI Disconnect reason 0x16 | **命令 Reason 0x13，事件 Reason 0x16**；确认 CIS 消失后 Release/Remove CIG | [R4 §7.3–§7.5](./Round4.md) |

## 3. 关键 Git 锚点（不是逐提交日志）

| 阶段 | Commit / 基线 | 用途 |
|---|---|---|
| Round1 最后核实 | `04a089e6a3d9476350e856ea322953e3f934a087` | HCI/BLE Passive Scan 基线 |
| Round2 最后核实 | `e883f70315f17a605f266e90e7e5618b5a7ea02d` | Bumble LE ACL |
| Round3 开始 | `6158e9a` | 当时的 R2.4 初版 |
| Round3 结束 | `a80cf1e8fe7d07078ae158e0f18aefcc73e80aed` | R3 双加密 ACL/音频服务发现完成 |
| R4.2 初版 | `ef4167291637d9444a0ab6cb797dd1382e5c5460` | 双耳 ASCS Config Codec 主体 |
| R5.1 | `15c68dcd4b5364fce81366d8c07ce72f50ba1579` | QoS Planner |
| R5.2-A | `7ef216eecb937f5e60e5c645c3d40b3928ef40cc` | CIG+ASCS QoS |
| R5.2-B 初版 | `c31c7f76588870a61c0ca76a10d76170817d53e8` | 双 CIS 实验入口 |
| 0x0C 解决 | `61851a01141fc586b0b27b9abc1425cb0d337d1b` | CIS Host bit32 |
| 0x12 / CIG 清理修复 | `5848597`、`2ef6ccf` | CIS Disconnect Reason 及 Pre-ACL CIG Recovery |
| **最终 HIL 基线** | **`eac486691fd4d7181d36bb09a620e942d0026936`** | R5.2-B 第三轮全生命周期成功 |

Round4 文档核对过的 Git 比较：R3 基线 `a80cf1e8` → Round4 最终 HIL 提交 `eac4866`，Ahead 68 commits / 22 files。**不要**将历史 HIL 基线误写成当前归档分支新 HEAD。

## 4. 核心实现路径索引（相对于仓库根）

| 路径 | 功能 |
|---|---|
| `src/controller_bootstrap.rs` | Bootloader / Operational Guarded Bootstrap |
| `src/audio_set.rs` | 双加密 ACL、上层工作流、Bond 指纹和 Cleanup |
| `src/main.rs` | 独立 CLI consent gate、参数解析 |
| `crates/bumble-adapter/src/init.rs`, `usb_fixed.rs` | 无 Reset 初始化、WinUSB Event/ACL 原生分帧与 ISO 尚待 HIL 的 Bulk-Out |
| `crates/bumble-adapter/src/connection_manager.rs`, `privacy.rs` | FAL、Resolving List |
| `crates/bumble-adapter/src/security.rs`, `stored_security.rs`, `commit.rs` | SMP 临时密钥、既有 LTK 复用、唯一持久提交 |
| `crates/bumble-adapter/src/gatt_session.rs` | 多 ACL 的 GATT/异步 CP-ASE 事件桥 |
| `crates/bap-client/src/codec_plan.rs`, `codec_config.rs`, `ase_read.rs` | LC3 Planner、Codec/ASCS 事务、Idle 特例 |
| `crates/bap-client/src/qos_plan.rs`, `cis_session.rs` | 双耳 QoS 计划、Enable/CIS 生命周期 |
| `crates/bumble-adapter/src/iso_capabilities.rs` | CIS Central / ISO Buffer 能力检查 |
| `crates/bumble-adapter/src/cig_control.rs`, `cis_host_feature.rs`, `cis_control.rs` | Set/Remove CIG、Host bit32、Create/Disconnect CIS |
| `crates/iso-scheduler/src/lib.rs` | **仅 frame quantum 骨架**，不是完整 ISO 时序系统 |

## 5. 证据归档位置与强弱

- Round1: 003 原厂 ColdBoot vs 004 Rust ColdSend USBPcap 与签名固件重建：见 [Round1 §3](./Round1.md)；仓库原有 [EXPERIMENT_004_R1_5B.md](../EXPERIMENT_004_R1_5B.md) 和 [EXPERIMENT_005_R1_6.md](../EXPERIMENT_005_R1_6.md)。
- Round2: R2.1/2.2/2.3 用户 Windows 实机日志，原始输出摘录见 [Round2 §4–§7](./Round2.md)。
- Round3: Stored Bond / Pairing / R3 完整审计见 [Round3 §15–§27](./Round3.md)；仓库已有 [R2_PAIRING_V2_HIL.md](../R2_PAIRING_V2_HIL.md)、[R2_ABOVE_ACL_STATIC_AUDIT.md](../R2_ABOVE_ACL_STATIC_AUDIT.md)。
- Round4: 七份原始 HIL 日志索引见 [Round4 §11](./Round4.md)；详细阶段门槛见仓库原有 [r4-ascs-config-codec.md](../r4-ascs-config-codec.md)、[r5-qos-plan.md](../r5-qos-plan.md)、[r5-config-qos.md](../r5-config-qos.md)、[r5-dual-cis.md](../r5-dual-cis.md)。**这次归档只收入四份 MD，不把敏感 Bond/固件/PCAP 拷入 Git。**
- 可复现事实强度：USBPcap/HCI 实际返回、用户提供的 CLI/Cargo 输出 > 当前源码/Commit > 文档推论。早期 Round 的“计划”不等于后期已经通过 HIL。

## 6. R5.3 接续点 / 尚未闭环

最短路径仍是：`R5.3-A ISO Data Path Setup/Remove HIL → R5.3-B 合成 PCM→LC3(100B/10ms)→2×ISO SDU TX → 可听左右耳 → R5.3-C 时序/抖动/稳定性 → R6`。

**待做/不能冒充成功**：ISO Data Path 和 LE HCI ISO Bulk-Out 发送均未硬件验证；LC3 Windows Encoder 未实际接到耳机；实测 Transport Latency `63,210 µs` 与 Presentation Delay `40,000 µs` 的时基关系仍需专门分析；最终 HEAD 的完整 `cargo test` 尚缺留档；长稳、异常单耳恢复、B3P 以外泛化均未验收。不得自动清除 Bond 或因清理失败直接热复位硬件。

**推荐下一轮阅读顺序**：`README.md → TIMELINE.md → BUG_FIX_REGISTER.md → Round4.md → Round3.md`，遇 R1/R2 的旧假设再回原文。

---

## 7. Round 5 / Review continuation — 2026-10-14 to 2026-10-15

> Round1–4 above remain historical snapshots. This section advances the active project view beyond the old R5.2-B cutoff.

| Stage | Status | Evidence / decision |
|---|---|---|
| R5.3 ISO Data Path | **Experiment PASS** | Setup/Remove ISO Data Path proven; bounded dual-CIS stream can complete |
| R5.3 LC3 First Sound | **Experiment PASS** | 48 kHz / 10 ms / 100 B mono per ear; 440 Hz L / 880 Hz R acoustically decoded by Buds3 Pro |
| R5.3 sustained realtime quality | **Known limitation** | pitch glide / timing drift traced to synchronous USB servicing + clock/credit coupling |
| Experiment architecture | **SEALED** | final investigation baseline `34f46809105567259f9614f648eadd0451c46b72` |
| Experiment source | **Archived** | complete tree under `deprecated/r5/` |
| Review architecture contract | **Frozen** | L0 Lifecycle; L1 Control/Media/HCI; IsoTxBridge; StreamClock; L2 Transport; L3 Platform |
| Execution model | **Frozen** | Core / HCI / Media RT / Capture / USB Reactor execution domains |
| Review-1 Runtime Kernel | **COMPLETE** | generation, bounded mailbox, cancellation, request/reply, serial context, fault propagation |
| Review-1 Async Transport | **COMPLETE** | concurrent Event+ACL pending RX, reassembly, cancellation, libusb async backend, persistent transfer reuse |
| Review-1 validation | **PASS** | `cargo test --workspace`: 48/48; `cargo check --workspace`: PASS; `cargo build --workspace`: PASS |
| HCI Host | **WIP at Round5 cutoff** | `hci-wip`; synthetic resetless attach/scan still unresolved at the end of Round5 |
| Reference Index | **COMPLETE** | `docs/reference-index/` provides file/function/type-level upstream oracle map |

### Round5 architecture pivot

The project no longer optimizes for “make the next HIL command work once”. Review code is accepted when:

1. ownership is explicit;
2. timing responsibility is explicit;
3. queues/backlogs are bounded;
4. deterministic behavior is covered by Cargo tests;
5. HIL is reserved for real Windows/USB/controller/earbud assumptions.

### Round5 cutoff implementation sequence

```text
Review-1 Runtime + Async Transport      ✅
        ↓
Review-2A HCI attach/capabilities/scan ← NEXT at Round5 cutoff
        ↓
Review-2B ACL/privacy/stored LTK
        ↓
Review-2C ATT/GATT
        ↓
Review-2D CIG/CIS/ISO Host
```

### Round5 active references

- [Round5.md](./Round5.md)
- [../../docs/design/REVIEW1_RUNTIME_TRANSPORT.md](../design/REVIEW1_RUNTIME_TRANSPORT.md)
- [../../docs/reference-index/README.md](../reference-index/README.md)

---

## 8. Round 6 / Review-2A + Review-2B + Review-2C completion — 2026-10-15 to 2026-10-18

> Round6 owns Review-2A/2B/2C implementation, static-audit and real-HIL changes from this webpage development session, plus ToolHub build-discipline and open-source governance decisions. The same chat then began Review-2D design/oracle audit but did not land 2D implementation before repeated connection interruption and chat migration. Round5 remains the Review-1 historical cutoff.

| Stage | Status | Evidence / decision |
|---|---|---|
| Review-2A HCI Host promotion | **COMPLETE** | HCI Host moved into default build; status-only Bumble host-init completion normalization covered by deterministic tests |
| Review-2A Firmware Bypass | **COMPLETE** | isolated L3 one-shot firmware owner; Bootloader→Operational or true AlreadyOperational no-op |
| Review-2A HIL | **PASS** | resetless attach, capabilities, passive extended scan, clean shutdown |
| Review-2B Privacy / Resolving List | **COMPLETE** | typed transaction + rollback + explicit cleanup |
| Review-2B FAL connect / cancel / disconnect | **COMPLETE** | R5-proven FAL parameters; requester-owned cancel; 0x13 command vs 0x16 event rule |
| Review-2B stored-LTK | **COMPLETE** | existing bond only; no SMP; Encryption Change is success gate |
| Review-2B connection generation | **COMPLETE** | handle reuse invalidates stale `ConnectionToken` |
| Review-2B ACL completion audit | **COMPLETE** | per-handle submitted/completed accounting; unknown/over-completion = fault |
| Review-2B dual ACL projection | **COMPLETE** | Bumble connection map remains sole mutable truth |
| Review-2B bond guard | **COMPLETE** | controller identity, set_size=2, 2 verified members, key presence, before/after SHA-256 fingerprint |
| Review-2B HIL | **PASS** | two existing-bond encrypted ACLs, reverse disconnect, privacy cleanup, bond unchanged |
| Review-2B final software gate | **PASS** | 151/151 tests; cargo check PASS; cargo build PASS |
| Review-2C async GATT | **COMPLETE** | typed event-driven GATT over Bumble Device ACL/L2CAP/ATT substrate; no synchronous ExternalAttTransport/GattClient public boundary |
| Review-2C deterministic gate | **PASS** | final Round6 local gate: 180/180 tests; cargo check/build PASS; working tree clean |
| Review-2C real HIL | **PASS** | both B3P members MTU=247, 14 services, PACS/ASCS/CAS discovered, CAS includes CSIS, descriptor probe + Supported Audio Contexts read, cleanup/bond unchanged |
| ToolHub build discipline | **COMPLETE** | cargo test/check/build use --workspace --locked; fail-closed git-sync-generated handles only provably safe dirty Cargo.lock recovery |
| Project license | **Apache-2.0** | LICENSE + NOTICE + THIRD_PARTY_NOTICES; Intel firmware excluded; vendored libusb LGPL boundary documented |

### Review-2A HIL evidence

```text
Firmware bypass: Booted
Capabilities: PASS
Scan: PASS reports=2 observations=2 truncated=false
Target seen: true
Shutdown: hci=Stopped transport=Cancelled
```

### Review-2B HIL evidence

```text
Firmware bypass: AlreadyOperational
Controller identity guard: PASS (44:A3:BB:36:94:1B)
Member 1: identity=E8:C9:13:EF:2F:23 handle=0x0800@gen1 encrypted=true key_size=0
Member 2: identity=E8:C9:13:F6:5C:E0 handle=0x0801@gen2 encrypted=true key_size=0
Dual encrypted ACL: PASS
Cleanup disconnect: handle=0x0801@gen2 reason=0x16
Cleanup disconnect: handle=0x0800@gen1 reason=0x16
Privacy cleanup: PASS
Bond store unchanged: true
Shutdown: hci=Stopped transport=Cancelled
```

`key_size=0` is not interpreted as a zero-byte encryption key; the Review success gate is the controller/Bumble encrypted connection state.

### Round6 internal chat-migration boundary

The original Round6 webpage session ended after Review-2C HIL PASS and Review-2D design/oracle audit. Engineering work then moved to a successor chat. This is preserved as a **conversation boundary only**, not as the final Engineering Round boundary.

```text
Review-1 Runtime + Async Transport      ✅
        ↓
Review-2A HCI attach/capabilities/scan ✅ COMPLETE + HIL
        ↓
Review-2B ACL/privacy/stored LTK       ✅ COMPLETE + HIL
        ↓
Review-2C ACL/L2CAP/ATT/GATT           ✅ COMPLETE + HIL
        ↓
Review-2D design / old-R5 oracle audit ✅
        ↓
chat migration
        ↓
Review-2D implementation + HIL         continued inside Round6
```

### Round6 final engineering sequence

```text
Review-1 Runtime + Async Transport      ✅ inherited COMPLETE
        ↓
Review-2A HCI attach/capabilities/scan ✅ COMPLETE + HIL
        ↓
Review-2B ACL/privacy/stored LTK       ✅ COMPLETE + HIL
        ↓
Review-2C ACL/L2CAP/ATT/GATT           ✅ COMPLETE + HIL
        ↓
Review-2D CIG/CIS/ISO Host             ✅ COMPLETE + HIL
        ↓
Round6 CLOSED
        ↓
Round7: Control semantic migration     ← NEXT
        ↓
StreamBinding
        ↓
StreamClock + IsoTxBridge
        ↓
Synthetic valid-LC3 First Sound
        ↓
WASAPI + ASRC
        ↓
Lifecycle / Recovery
        ↓
Profiling / HIL hardening
```

### Review-2D final status

| Stage | Final Round6 status | Evidence / boundary |
|---|---|---|
| CIG/CIS lifecycle | **SOFTWARE + HIL PASS** | typed Set/Remove CIG, Create/Disconnect CIS, asynchronous terminal-outcome reduction; dual live CIS observed on B3P |
| ISO Data Path | **SOFTWARE + HIL PASS** | HCI Input path setup/remove projected through Bumble and exercised on both real CIS |
| complete ISO SDU Host | **SOFTWARE + HIL PASS** | pinned Bumble owns ISO sequence/PB/fragmentation/controller queue; real packets reached BE200/Buds3 Pro |
| capacity/admission | **SOFTWARE + HIL PASS** | pre-Bumble complete interval-group admission; controller window observed as 8 packets |
| runtime lane | **SOFTWARE + HIL PASS** | dedicated bounded `HciIsoTx`; 100 stereo interval groups sent through real data lane |
| credit audit | **HIL PASS** | 100 frames × 2 ears = 200 submitted / 200 completed / 0 in-flight after drain |
| teardown gate | **HIL PASS** | ISO drain → Remove Path ×2 → Disconnect CIS ×2 → Disable/Release ASE → Remove CIG → ACL/privacy cleanup |
| persistent safety | **HIL PASS** | bond fingerprint unchanged; no SMP/re-pairing; privacy cleanup true |
| final deterministic gate | **PASS** | 247/247 tests; cargo check PASS; cargo build PASS; working tree clean |

### Review-2D HIL evidence

```text
[R2D/DISCOVERY]
identity=E8:C9:13:EF:2F:23 current=4E:D9:B1:8B:15:FF connectable=PASS
identity=E8:C9:13:F6:5C:E0 current=57:A6:A5:F2:30:00 connectable=PASS

[R2D/ASCS]
E8:C9:13:EF:2F:23 Sink ASEs=2 selected ASE=1 handle=0x0046
E8:C9:13:F6:5C:E0 Sink ASEs=2 selected ASE=1 handle=0x0046

Firmware bypass: AlreadyOperational
Controller identity guard: PASS (44:A3:BB:36:94:1B)

Left:  identity=E8:C9:13:F6:5C:E0 CIS=0x0900
Right: identity=E8:C9:13:EF:2F:23 CIS=0x0901

Controller ISO packet window: Some(8)
ISO Host audit: frames=100 submitted=200 completed=200 in_flight_after=0
ISO drain + reverse teardown: PASS

Cleanup ACL disconnect: handle=0x0801@gen2 reason=0x16
Cleanup ACL disconnect: handle=0x0800@gen1 reason=0x16
Privacy cleanup: true
Bond store unchanged: true
Shutdown: hci=Stopped transport=Cancelled
```

The codec-opaque 100-byte transport pattern caused audible digital output from the earbuds, which is useful supplementary endpoint evidence that SDUs reached the remote codec/output pipeline. It is **not** counted as valid-LC3 or acoustic First Sound; that Review-path gate belongs to Round7 Media work.

### Round6 active references

- [Round6.md](./Round6.md)
- [Round5.md](./Round5.md)
- [BUG_FIX_REGISTER.md](./BUG_FIX_REGISTER.md)
- [../reference-index/README.md](../reference-index/README.md)

Round7 begins at **Control semantic migration**. HCI Host below that boundary is treated as sealed substrate: raw CIS handles, HCI ISO sequence/PB/fragmentation, controller credits and USB endpoint ownership remain below Control/Media. Number Of Completed Packets continues to release transport capacity only and must never define media time.



---

## 9. Round 7 / Control semantic migration + product data plane — 2026-10-18 (ACTIVE)

Round7 从 Round6 已通过真机验证的 HCI substrate 向上生长。当前 chat 已完成产品 Control semantic path、transport-neutral StreamBinding、LocalStreamClock、valid LC3 producer、IsoTxBridge、logical HCI ISO route/lane，并准备好独立 `round7 first-sound` 真机入口；**valid-LC3 First Sound HIL 尚未执行**。

### Round7 current engineering sequence

```text
Round6 Review-2D substrate                  ✅ COMPLETE + REAL HIL
        ↓
Control semantic connection/security        ✅ SOFTWARE COMPLETE
        ↓
PACS/ASCS/CAS/CSIS discovery               ✅ SOFTWARE COMPLETE
        ↓
Codec / CIG / QoS / Enable                  ✅ SOFTWARE COMPLETE
        ↓
Create CIS / ISO Path / STREAMING gate      ✅ SOFTWARE COMPLETE
        ↓
HCI logical route ACK                       ✅ SOFTWARE COMPLETE
        ↓
transport-neutral StreamBinding             ✅ SOFTWARE COMPLETE
        ↓
Synthetic PCM 400/600 Hz                    ✅ SOFTWARE COMPLETE
        ↓
valid LC3 48k / 10ms / 100B                 ✅ SOFTWARE COMPLETE
        ↓
LocalStreamClock absolute grid              ✅ SOFTWARE COMPLETE
        ↓
IntervalGroupScheduler / IsoTxBridge        ✅ SOFTWARE COMPLETE
        ↓
logical HCI ISO bounded lane                ✅ SOFTWARE COMPLETE
        ↓
Round7 valid-LC3 First Sound HIL            🟡 READY / NOT YET RUN
        ↓
full Core/Lifecycle runtime                 ⏳ NEXT AFTER HIL
        ↓
egui / WASAPI / ASRC                        ⏳ FUTURE
```

### Round7 semantic-Control boundary

| Area | Current status | Key rule |
|---|---|---|
| dual stored-bond connection path | **Software complete** | bit32 → scan/RPA → privacy → dual ACL → stored LTK |
| audio-service discovery | **Software complete** | PACS/ASCS/CAS/CSIS; multi-Sink-ASE aware |
| ASCS operation FSM | **Software complete** | Write Response + CP success + ASE notification + independent readback |
| Codec/QoS/Enable planners | **Software complete** | fixed first product policy derived from discovered capabilities |
| CIS / ISO Path | **Software complete** | Control uses `CisRef`; raw controller handles remain in HCI Host |
| Streaming gate | **Software complete** | nonblocking ENABLING→STREAMING readback gate with semantic deadline |
| reverse teardown | **Software complete** | route → path → CIS → ASE Release → CIG → ACL → privacy |
| StreamBinding | **Software complete** | route ACK required before Control exposes Media-facing binding |

### Round7 logical-route / data-plane boundary

```text
StreamBinding
(SessionId, StreamId, format, delay, topology)
        │
        ▼
LogicalIsoTxBridge
        │
        ▼
LogicalIsoSduGroupRequest
(session_id, stream_id, left, right)
        │
        ▼
HCI Host logical route
(SessionId, StreamId, AudioSide)
        │
        ▼
CisRef
        │
        ▼
raw CIS handle
(HCI Host internal only)
```

Logical route admission requires both CIS links live and both HCI Input Data Paths ready. Route is session-fenced, exact replay is idempotent, conflicting rebind is rejected, and route entries are invalidated by path/CIS teardown.

### Round7 media-time rule

Initial `LocalStreamClock` uses one authoritative absolute 10 ms grid:

```text
target(FrameId N) = epoch + N × 10,000 us
```

Controller completions never advance `FrameId`. Callback jitter does not move the grid. A late callback skips expired logical intervals rather than stretching the period.

`LogicalIsoTxBridge` backpressure contract:

```text
logical HCI lane Full
→ drop current complete stereo interval
→ no wait
→ no retry
→ no media-clock change
→ continue at next FrameId/deadline
```

For the dedicated First Sound HIL, any such drop is an acceptance failure.

### Round7 First Sound HIL entry

```powershell
$fw = 'C:\STanJK\Development\LEAudioLab\BE200\firmware'
$bond = Join-Path $env:LOCALAPPDATA 'BE200AudioHub\bonding'

.\target\debug\be200hub.exe `
    round7 first-sound `
    --sfi (Join-Path $fw 'be200_intel_windows_24.60.0.4_usb_verified.sfi') `
    --ddc (Join-Path $fw 'ibt-0291-0291.ddc') `
    --bond-root $bond `
    --name "Galaxy Buds3 Pro (2F23)" `
    --connect-seconds 12 `
    --frames 100 `
    --confirm-first-sound-hil
```

Fixture:

```text
Left  400 Hz
Right 600 Hz
48 kHz
10 ms
100 B LC3 / ear
~ -50 dBFS digital peak
100 ms fade-in/out
~1 s default duration
```

Safety: first run with earbuds out of ears; dBFS is not calibrated acoustic SPL.

### Round7 current deterministic gate

```text
cargo test --workspace --locked
350 passed; 0 failed; 0 ignored

cargo check
PASS

cargo build
PASS

git status
## main...origin/main
```

### Round7 claim boundary at chat migration

Allowed:

> Control semantic path + product valid-LC3 Media/Clock/Bridge/logical-HCI data plane are software-complete; dedicated real-hardware First Sound HIL is ready.

Not yet allowed:

> Round7 valid-LC3 First Sound HIL PASS.

The new HIL still reuses sealed Review-2D setup/teardown as an oracle; full Core/Lifecycle product runtime integration is the next software step after HIL.

### Round7 active references

- [Round7.md](./Round7.md)
- [Round6.md](./Round6.md)
- [BUG_FIX_REGISTER.md](./BUG_FIX_REGISTER.md)
- [../reference-index/README.md](../reference-index/README.md)

This chat migration is **not** the Round7 engineering boundary. The next chat continues Round7 from the valid-LC3 First Sound HIL.

## 12. Round 8 / V2 structural closure + live relay baseline

Round8 is **CLOSED**. It completed the ownership refactor and then proved the
first real Windows live-audio product path.

### 12.1 Structural closure

```text
L0 Core
L1 Control
L1 Media
L1 HCI
L2 Transport
L3 Platform
```

The frozen route/clock/credit invariants from Round7 were preserved while
Control was decomposed into durable model, operation progress, reducers,
discovery/planning/ASCS and interface boundaries.

### 12.2 Real HIL progression

```text
Round7 valid-LC3 First Sound            REAL HIL PASS
Round8 current-path First Sound         REAL HIL PASS
Windows live Process Loopback           REAL HIL PASS ×2 @10 s
300 s longevity data window             reached 300/300 s
```

Round8 also fixed the initial Process Loopback `E_ILLEGAL_METHOD_CALL` by
making the activation completion handler agile, added longevity mode, and added
10%-interval runtime snapshots.

### 12.3 Round8 teardown handoff

The first five-minute run proved the data window but failed during graceful
Stop with dual ASE cleanup timeout. Before Round8 closed:

```text
742eb75c  separate graceful Stop from failure rollback ordering
a48b2a54  accept cached Codec Configured after ASE Release
a11efdff  add longevity runtime snapshots
```

The long-session teardown defect remained open and became the opening problem
of Round9.

See [Round8.md](./Round8.md).

## 13. Round 9 / long-session teardown + crash recovery + ACL boundary

Round9 is **ACTIVE**. The CLI still uses the `round8 live-relay` namespace;
that command name does not define the Engineering Round.

### 13.1 Dirty-controller recovery defect

Ctrl+C during an active session killed the sole userspace Host while BE200/peer
state survived. Subsequent resetless launches repeatedly failed member
visibility until the BE200 was power-cycled.

Frozen recovery direction:

```text
CLEAN previous generation
→ resetless attach

DIRTY / UNKNOWN previous generation
→ HCI Reset + full Host reinitialization
```

A graceful Ctrl+C path, durable DIRTY/CLEAN ownership marker and supervisor are
Wave-1 work.

### 13.2 Teardown state-machine corrections

```text
96cf90a5  graceful Release pivots on ASE RELEASING
41742199  expose Release gate timeout state
2672f75a  attach gate snapshot to ASE operation
30a8589c  test import fix
85300c88  use Write Command for ASCS Control Point
87c3352c  align ASCS write-command tests
```

The 10%-longevity observer path was exonerated: a 30 s **normal** run reproduced
the same failure.

### 13.3 Current authoritative failure

After Write Without Response alignment:

```text
AseReleaseGateTimeout {
  side: Right/Left,
  gate: {
    phase: WaitingGates,
    pending_request_id: None,
    write_complete: true,
    cp_success: false,
    notified_state: None
  }
}
```

Thus local WriteCommand completion occurred, but neither CP SUCCESS nor ASE
state notification was observed on either ear.

### 13.4 Current lower-boundary diagnostic

`d1fb532c` + `084fa605` expose:

```text
bumble_pending
audit_in_flight
audit_limit
waiting_estimate = bumble_pending - audit_in_flight
```

Next-HIL classification:

```text
waiting_estimate > 0
  → blocked in Bumble Host ACL queue

waiting_estimate == 0 && audit_in_flight > 0
  → submitted to HCI; controller completion outstanding

waiting_estimate == 0 && audit_in_flight == 0
  → Host/controller TX retired; inspect response/peer layer
```

No real-hardware result from this new ACL audit exists yet.

### 13.5 Immediate next step

Do not run another 300 s test yet.

1. Start from a clean BE200/Buds state after any failed teardown.
2. Run 30 s normal `round8 live-relay`.
3. Capture the ACL teardown audit if Stop fails.
4. Choose the next layer from the classification above.

See [Round9.md](./Round9.md).
